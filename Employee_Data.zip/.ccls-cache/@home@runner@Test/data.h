#include <iostream>
#include <string>
#include "employee.h"
#include "main.cpp"
using namespace std;

  
  if (dataRequest == "Yes" || dataRequest == "yes"){

      int guessAttempt = 0;
      int keyAttempt;
      int securityKey = 1234;

      while (guessAttempt < 3){

        cout << "Input security key: ";
        cin >> keyAttempt;

        if (keyAttempt == securityKey){

          Employee employee0(Namerequest, Companyrequest, Agerequest);
          cout << endl;
          employee0.data();
          cout << endl;
          return 0;
          
        }

        cout << "Wrong key!" << endl;
        guessAttempt++;
        
      }

     cout << "Attempts limit exceeded. Access Denied.";
    return 0;
      
    }

  else {
    cout << "Very well. Have a good day.";
  }


  }